﻿global using Abc.Lingua.indo_euro.germanic.western;
global using Abc.Lingua.indo_euro.hellenic;
global using Abc.Lingua.indo_euro.italic;
global using Abc.Lingua.indo_euro.italic.romance.west.gallic;
global using Abc.Lingua.japonic;
global using AbcExtNUnit.Attributes.Directive;
global using AbcStuff.Text;