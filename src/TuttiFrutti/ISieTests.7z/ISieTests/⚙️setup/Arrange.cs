﻿namespace AbcDataOpsTests.Setup;
public abstract class Arrange
{
    protected readonly string? NullStr = null;

    protected bool True = true;
    protected bool False = false;
}