﻿namespace AbcDataOpsTests.ISie.Number;
public class Demo : Setup.Arrange
{

    // IsNatural
    // IsPerfect
}
