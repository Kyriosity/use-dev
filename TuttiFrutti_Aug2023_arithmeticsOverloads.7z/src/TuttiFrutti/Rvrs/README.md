# `Rvrs` - Reversible

Development that comprises Reversible items/values/actions.

Other definitions:\
|- [Basics](../README.md)
