# Multifaceted Value :diamond:

OWN ENGINE (with rounding, TABLES !, optmizied funcs, tree search

REFINING PREC. FOR MISC, TYPES !

<div dir="rtl">?Levels&nbsp;-</div>
<div dir="rtl">!300&nbsp;-</div>
<div dir="rtl">?What 300&nbsp;-</div>
<div dir="rtl">?What levels&nbsp;-</div>
&nbsp;

You may find the folklore right above dull but not pointless. Computers operate with pure numerics, however, unless it's a math application,these numbers describe physial world and desperately need units.


What's even COMPLEXER there's always a MIX OF THIS VALUES.

RESERVING UNITS IN CONTEXT MAYBE THE EPIC FAIL. (catastrophes)
Example: age, metric in avia

MULTI-CULTURE WORLD WIDE


REFER var divisions !

```csharp
var recordedMarsApproach = 12_0000; // miles or kilometers?
var recentMarsApproachMiles = ; // good for LINEAR FORTRAN IN ODYSEE
```

```csharp
WATER TEMPERATURE. I don't care for fractions - so, INT

var novelF = Temperature.Fahrenheit(451); // ToDo: rename T ENFLAM
var scientific_edition = $"F->K {novelF.Kelvin}";
TYPEOF -> INT

var spaceZero = Temperature.Kelvin<double>(2.725);
var soundEuroAustronaut = Temperature.Celsius(36.6);
var diffENTROPY = NASA.CALC_ENTROPY(soundEuroAustronaut.Fahrenheit - spaceZero);

```

LINK TO IMPLEMENTATION

## Principal decisions

### Why no arithmetic overloads ?

Our next GUST would be to .

Say, 

Weight.Ton() + 


WRONG!


### Why no comparisson



## CONTINUED

In decent application they will be PACKED but it's better to have a SSSS solution.

miles or kilometers? HOW MUCH ASTRO units is that ?

The way numbers are declared 

In programming languages one may /// units from context or explicitly name them.

As a start of this project let's sketch TEMPERATURE

## Solution

```csharp
var temperature SYNONYM = Temperature.Celcius(95); 

```


TWO DIFFERENT OPTIONS: LOOSE set and WIRED (cross-calced)

INDEXING - OPTIONAL, explain why

HIERARCHY ! 

FABRIC!


<<<============= we are here with developed

ADJUSTMENT Of FUNCs to N (e.g. 273.15 and double)

CONVERSION ISSUES: 
	TABLED | FUNC | DECIMAL
		CALC thru other unit

?? min max values (input only once, e.g. that temperature can't be below 0K)

?? CONSTANTS! (which are also dependent of input)

?? CONSTANTS

?? setting default of calc

?? U 'd LIKE TO DESIGNATE TO A FIXED or CUSTOM unit sys, so that to combine in output. E.g. temperature with length

?? MUCH values have very many ... (light year, parsec). 
?? are influenced by

? read-only props
? format : inch or ?

??		UNIT SYS.
??		CAMEL	

CONVERSION
		CHAINED FUNCS, 
		TABLED Funcs

## Going abstracter

Not only numerics
Movie scores from diff db


LINGUA

## Technical challenges

+ For accumulating inaccuracy
		ADD TEST !
+ For camel transfomation

## Future features

VARIOS TYPE WITHIN N
HIERARCHY

# Recipies and Q&A

## What for do i need custom functions?
+ extend, better up to unamanged code, other types (custom big nums)

## Why can i not

### On purpose

+ **Use equality operators** `==` . Was'nt `temperatureA == ` it not PLANNED?\
It's ON PURPOSE

+ **Unary operations**\


### Not implemented

## How can i

