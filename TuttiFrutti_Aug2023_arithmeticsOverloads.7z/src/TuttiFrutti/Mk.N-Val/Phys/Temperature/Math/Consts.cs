﻿namespace Mk.N_Val.Phys.Temperature.Math;
internal static class Consts
{
    internal const double KminusC = 273.15;
}
