﻿using Abc.Arithmetic;
using Mk.N_Val.Arithmetic;
using N_Val;
using N_Val.Phys.Temperature;
using System.Numerics;

namespace Mk.N_Val.Phys.Temperature;

public interface IOpTempEdit<N> : IOpTemp<N>, ITempEdit<N> where N : INumber<N> { }

public interface IOpTemp<N> : ITemp<N> where N : INumber<N>
{
    static IOpTempEdit<N> operator +(IOpTemp<N> x1, IOpTemp<N> x2) => Do(x1, x2, NamedOps<N>.Add);
    static IOpTempEdit<N> operator -(IOpTemp<N> x1, IOpTemp<N> x2) => Do(x1, x2, NamedOps<N>.Subtract);
    static IOpTempEdit<N> operator *(IOpTemp<N> left, N f) => Do(left, f, NamedOps<N>.Multiply);
    static IOpTempEdit<N> operator /(IOpTemp<N> left, N f) => Do(left, f, NamedOps<N>.Divide);
    static IOpTemp<N> operator %(IOpTemp<N> left, N f) => Do(left, f, NamedOps<N>.Modulo);

    private static IOpTempEdit<N> Do(UValue<N> x1, UValue<N> x2, Func<N, N, N> op) =>
        FacetValueOps.Do<Temperature<N>, Unit, N>(x1, x2, op);

    private static IOpTempEdit<N> Do(UValue<N> x1, N factor, Func<N, N, N> op) =>
        FacetValueOps.Do<Temperature<N>, Unit, N>(x1, factor, op);

}


