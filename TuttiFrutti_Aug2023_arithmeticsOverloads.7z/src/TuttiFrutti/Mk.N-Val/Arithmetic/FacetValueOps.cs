﻿using N_Val;
using System.Numerics;

namespace Mk.N_Val.Arithmetic;
internal static class FacetValueOps
{
    public static W Do<W, U, N>(UValue<N> left, UValue<N> right, Func<N, N, N> op)
        where W : WiredValues<N, U>, new() where N : INumber<N> where U : Enum {

        var x1 = ((WiredValues<N, U>)left).Get(out U unit);

        var result = new W();
        result.Set(op(x1, ((WiredValues<N, U>)right).Get(unit)), unit);
        return result;
    }

    public static W Do<W, U, N>(UValue<N> left, N factor, Func<N, N, N> op) where W : WiredValues<N, U>, new() where N : INumber<N> where U : Enum {
        var x1 = ((WiredValues<N, U>)left).Get(out U unit);

        var result = new W();
        result.Set(op(x1, factor), unit);
        return result; ;
    }
}

