﻿using System.Numerics;

namespace Abc.Arithmetic;
public static class NamedOps<N> where N : INumber<N>
{
    public static Func<N, N, N> Add = (x1, x2) => x1 + x2;
    public static Func<N, N, N> Subtract = (x1, x2) => x1 - x2;
    public static Func<N, N, N> Multiply = (x1, x2) => x1 * x2;
    public static Func<N, N, N> Divide = (x1, x2) => x1 / x2;
    public static Func<N, N, N> Modulo = (x1, x2) => x1 % x2;
}
