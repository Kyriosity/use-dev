﻿namespace Abc.Ltd;
public interface IRestraint { }

