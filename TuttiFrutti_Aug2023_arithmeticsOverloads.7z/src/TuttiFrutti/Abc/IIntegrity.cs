﻿namespace Abc;
public interface IIntegrity
{
    bool IsTampered { get; set; }
}
