﻿using Mk.N_Val.Phys.Temperature.Build;
using System.Numerics;

namespace N_Val.Test_Learn.Operations;
public class ArithmeticsDemo
{
    [Test]
    [TestCase(1, 2)]
    [TestCase(-7, 17)]
    [TestCase(-7.02341, 17.23123)]
    public void AddSubstract<N>(N left, N right) where N : INumber<N> {

        var heaterN = Temperature.Celsius(left);
        Assert.That(heaterN.Celsius++, Is.EqualTo(left));
        ++heaterN.Celsius;

        var absZero = Temperature.Kelvin(N.Zero);
        var thermometer = Temperature.Celsius(left);

        var sciMeasure = thermometer.Kelvin - absZero.Kelvin;

        var temp1 = Temperature.Celsius(100);
    }

    [Test]
    public void Multiply() {
        const double seed = 273.15;
        var subj = Temperature.Kelvin(seed);
        subj.Celsius *= 7;

    }

    [Test]
    public void Divide() {
        // + remainder !
    }
}
