﻿using Mk.N_Val.Phys.Temperature.Build;

namespace N_Val.Test_Learn.Arithmetic;

public class EqualityTests
{
    [Test]
    public void EQUAL() {
        var t1 = Temperature.Celsius(82);
        var t2 = Temperature.Celsius(87);

        Assert.That(t1 == t2, Is.True);

        var sciAbsZero = Temperature.Kelvin(273.15);
        var swedenAbsZero = Temperature.Celsius(0);

        Assert.That(sciAbsZero == swedenAbsZero, Is.True);
    }

    [Test]
    public void Subtract() {

    }

    [Test]
    public void Hetero() {
        // chain of diff ops and N
    }

}
