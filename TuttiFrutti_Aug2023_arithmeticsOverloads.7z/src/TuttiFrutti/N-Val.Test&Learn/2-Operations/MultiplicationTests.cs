﻿using Mk.N_Val.Phys.Temperature.Build;

namespace N_Val.Test_Learn.Arithmetic;

public class MultiplicationTests
{
    [Test]
    public void Multiply() {
        var melting = Temperature.Celsius(7);

        int factor = 3;
        var increased = melting * factor;

        double couldIncr = 1.2345;
        couldIncr++;

        int t = (int)couldIncr;

        Assert.That(increased.Celsius, Is.EqualTo(21));
    }
}
