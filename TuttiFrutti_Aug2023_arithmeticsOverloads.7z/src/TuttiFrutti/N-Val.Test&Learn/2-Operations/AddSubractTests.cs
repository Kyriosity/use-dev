﻿using Mk.N_Val.Phys.Temperature;
using Mk.N_Val.Phys.Temperature.Build;
using N_Val.Phys.Temperature;
using System.Numerics;
using TD.N_Val;

namespace N_Val.Test_Learn.Arithmetic;

public class AddSubractTests
{
    [Test]
    public void Concept() {
        var f1 = Temperature.Kelvin(1);

        var averageMay = Temperature.Celsius(12);
        var averageJune = Temperature.Celsius(19);
        var averageJuly = Temperature.Celsius(21);
        var averageAug = Temperature.Celsius(23);
        var sum = averageMay + averageJune + averageJuly + averageAug;

        Assert.That(sum.Celsius, Is.EqualTo(12 + 19 + 21 + 23));

        var surface = Temperature.Fahrenheit(451);
        surface.Fahrenheit = 1;
        surface -= Temperature.Celsius(100);

        Assert.That(surface.Celsius, Is.EqualTo(12));
        surface.Fahrenheit = 1;

    }

    [Test, TestCaseSource(typeof(ExpandedTestData), nameof(ExpandedTestData.TRows))]
    public void Add<N>((Func<N, IOpTemp<N>> build, N val) x1, (Func<N, IOpTemp<N>> build, N val) x2,
        (N val, N delta) expected) where N : INumber<N> {

        var left = x1.build(x1.val);
        var right = x2.build(x2.val);
        var result = left + right;
        Assert.That(result.Celsius, Is.EqualTo(expected.val).Within(expected.delta));
    }

    [Test, TestCaseSource(typeof(TestArgs.Temperatures.Math), nameof(TestArgs.Temperatures.Math.Diffs))]
    public void Subtract<N>((N x1, Unit x1Unit, N x2, Unit x2Unit, (N val, Unit unit, N delta) expected) args)
        where N : INumber<N> {

        //foreach (var builder in Builders) {
        //    var left = builder.Unite(args.x1Unit, args.x1);
        //    var right = builder.Unite(args.x2Unit, args.x2);
        //    var result = left - right;

        //    Assert.That(result.G, Is.EqualTo(args.expected.val).Within(args.expected.delta));
        //}
    }

}

public interface IBuilder
{
    public IOpTempEdit<N> Unite<N>(Unit unit, N value) where N : INumber<N>;
    public IOpTempEdit<N> Kelvin<N>(N value) where N : INumber<N>;
    public IOpTempEdit<N> Celsius<N>(N value) where N : INumber<N>;
    public IOpTempEdit<N> Fahrenheit<N>(N value) where N : INumber<N>;
}

public static class ExpandedTestData
{

    public readonly static object[] TRows = {
        new object[] { Stubs<int>.CelsiusBuilder, 11, Stubs<int>.CelsiusReader },
        new object[] { Stubs<double>.KelvinBuilder, 2.27, Stubs<double>.CelsiusReader }
    };
}

public static class Stubs<N> where N : INumber<N>
{
    public static Func<N, IOpTemp<N>> KelvinBuilder = x => Temperature.Kelvin(x);
    public static Func<N, IOpTemp<N>> CelsiusBuilder = x => Temperature.Celsius(x);

    public static Func<IOpTemp<N>, N> CelsiusReader = x => x.Celsius;
}
