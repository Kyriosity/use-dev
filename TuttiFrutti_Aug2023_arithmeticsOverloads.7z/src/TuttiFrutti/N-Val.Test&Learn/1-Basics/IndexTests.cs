﻿namespace N_Val.Test_Learn.Basics;
public class IndexTests
{
    [Test]
    // providers of not full open ? By Interface ?
    public void GetByIndex() {
        Assert.Ignore("Implemented next");
    }

    [Test]
    // providers of full open
    public void GetSetByIndex() {
        Assert.Ignore("Implemented next");
    }
}
